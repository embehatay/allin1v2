from third_party import iso639

print(str(iso639.Lang("Vietnamese")))